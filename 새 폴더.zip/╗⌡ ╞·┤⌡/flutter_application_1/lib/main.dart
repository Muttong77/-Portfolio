import 'package:flutter/material.dart';
import 'package:row_column/screen/homescreen.dart';

void main() {
  runApp(
    MaterialApp(
    home: Homescreen(),
    ),
  );
}
