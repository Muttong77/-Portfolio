import 'package:flutter/material.dart';

const colors=[
  Colors.red,
  Colors.orange,
  Colors.yellow, 
  Colors.green,

];