import 'dart:math';

import 'package:flutter/material.dart';
import 'package:row_column/color/color.dart';

class Homescreen extends StatelessWidget {
  const Homescreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          width: double.infinity,
          height: double.infinity,
          color: Colors.white,  
          child: Column( // 전체 작업공간
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [ // 첫 번쨰 줄
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround, // 스페이스 어라운드로 간격 조절
                  children: [
                    Container(
                      child: Container(
                      height: 50.0,
                      width: 50.0,
                      color: Colors.red,
                ),
              ),
              Container(
                      child: Container(
                      height: 50.0,
                      width: 50.0,
                      color: Colors.orange,
                ),
              ),
              Container(
                      child: Container(
                      height: 50.0,
                      width: 50.0,
                      color: Colors.yellow,
                ),
              ),
              Container(
                      child: Container(
                      height: 50.0,
                      width: 50.0,
                      color: Colors.green,
                ),
              ),
                  ],
                ),
              ),
              Container( // 두 번째 줄
                child: Container(
                  height: 50.0,
                  width: 50.0,
                  color: Colors.orange,
                ),
              ),
               Container( // 세 번째 줄
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end, // 엔드로 끝에 붙히기
                  children: [
                    Container(
                      child: Container(
                      height: 50.0,
                      width: 50.0,
                      color: Colors.red,
                ),
              ),
              Container(
                      child: Container(
                      height: 50.0,
                      width: 50.0,
                      color: Colors.orange,
                ),
              ),
              Container(
                      child: Container(
                      height: 50.0,
                      width: 50.0,
                      color: Colors.yellow,
                ),
              ),
              Container(
                      child: Container(
                      height: 50.0,
                      width: 50.0,
                      color: Colors.green,
                ),
              ),
                  ],
                ),
              ),
              Container( // 네 번째 줄
                height: 50.0,
                width: 50.0,
                color: Colors.green,
              ),
              
            ],
            
          ),
        ),
      ),
    );
  }
}